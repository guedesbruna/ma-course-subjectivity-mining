This package contains 4 files - 2 files contain test data from Facebook (which was also the source of training data) in each of Hindi and English and 2 files contain surprise test set from other social media in each of Hindi and English. These are as follows -
agr_en_fb_test.csv - Facebook test set for English
agr_hi_fb_test.csv - Facebook test set for Hindi
agr_en_sm_test.csv - Social Media test set for English
agr_hi_sm_test.csv - Social Media test set for Hindi

All the sets contain the IDs and the text in CSV format.

You need to submit the labels for each ID in <ID,label> format on CodaLab. Further submission instructions are available on the CodaLab page.
